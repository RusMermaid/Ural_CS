//V2.0.5
using System;
namespace Ural_CS_Rider.Ural_translator_compiler

{
  public class Location
  {
    public Location()
    {
    }
  }
}
