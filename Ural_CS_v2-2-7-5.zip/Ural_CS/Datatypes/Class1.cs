﻿namespace Datatypes;
public class Class1
{

}

