﻿global using Datatypes;

global using Datatypes.Booleans;

global using Datatypes.Numbers;
global using Datatypes.Numbers.OtherNumbers;
global using Datatypes.Numbers.OtherNumbers.Binary;
global using Datatypes.Numbers.OtherNumbers.Octal;
global using Datatypes.Numbers.OtherNumbers.Hexadecimal;

global using Datatypes.Strings;

global using Datatypes.Collections;