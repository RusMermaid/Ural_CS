﻿namespace Errors;
public class Class1
{

}

