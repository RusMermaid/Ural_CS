﻿namespace Errors.SyntaxInvalidError.ErrorDatatypes.ErrorOutOfRange;

public class Str64OutOfRangeError : Error
{
    public Str64OutOfRangeError(int _position_start, int _position_end, string _error_name = "Длина строки не в диапазоне: ", string _discription = "длина стр64 не может превышать 18446744073709551615") : base(_position_start, _position_end, _error_name, _discription)
    {
            
    }
}