# Ural
This is a project to create a programming language in Russian
