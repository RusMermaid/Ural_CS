

class Number:
    def __init__(self, number_value):
        self.number_value = number_value