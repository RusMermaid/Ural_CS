//V2.0.5
using System;
namespace Ural.Ural_translator_compliler;

{
  public class Location
  {
    public Location()
    {
    }
  }
}
