﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Examples
{
    public interface IExample
    {
        void Run(string pythonExePath, string dasPlotPyPath);
    }
}
